<template>
    <div class="flex w-full items-center justify-center">
        <div class="max-w-5xl w-full">
            <slot></slot>
        </div>
    </div>
</template>

<script setup>
</script>

<style>

</style>
